# Review bundle — review_bundle_20261020

Built: 2026-10-20T21:43:26+08:00
Branch: `overnight/flash-20261020-0058`
Source commit: `d70820b2d63f8d42b73b77ff7a73d44b64a9c811`
Tests at build time: 61 passed (offline; no paid model calls)

This bundle is a read-only handoff package for the EEG-AI-Scientist Flash run.
It contains:

- current Python source, tests, configurations, prompts, and project metadata;
- current run reports (`reports/flash_20261020_0058/`);
- the `literature_v1` Scientist answer, structured final result, actual input,
  message record, evidence index, read/injection record, and public source
  snapshots;
- the two synthetic diagnostic cases' inputs, execution records, and final
  judgments;
- the explanation-regression trace.

It deliberately excludes:

- `credentials/` and any key material;
- `data/private/` and `review_only/` (evaluator/private case material);
- `runs/.../PRIVATE_MAPPING.json` (the alias-to-source-case mapping);
- `runs/.../budget.json` (not needed for this review; the ledger remains local);
- `src.zip`, `tests.zip`, Git internals, caches, and the previous round's
  `artifacts/review_bundle.zip`.

Important provenance:

- The synthetic cases are synthetic feature tables, not recorded EEG.
- The literature sources are public web snapshots fetched by the project; they
  are included for audit, not as a redistribution license.
- The Scientist's original `final_answer.md` / `final.json` are unchanged. The
  separate `REASONING_REVIEW.md` and `COVERAGE_RECHECK.md` are reviewer notes.
- Original files under `runs/` were read only; this archive was written outside
  the run directories.

Verify with:

```powershell
python VERIFY_BUNDLE.py
```
