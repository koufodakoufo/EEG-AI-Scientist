"""Verify every file listed in MANIFEST.json against its SHA-256."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
bad: list[str] = []
for item in manifest["files"]:
    path = root / item["path"]
    if not path.is_file():
        bad.append(f"missing: {item['path']}")
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != item["sha256"]:
        bad.append(f"hash mismatch: {item['path']}")
if bad:
    raise SystemExit("\n".join(bad))
print(f"OK: {len(manifest['files'])} files verified")
