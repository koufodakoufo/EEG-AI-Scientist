# Review bundle 鈥?review_bundle_emotion_20261021

Built: 2026-10-21T11:59:15+08:00
Branch: `overnight/flash-20261020-0058`
Source commit: `43f4524589a40d66a7ab907112308ae91badf2be`
Tests at build: 68 passed (offline; no paid model calls)
Project API spend at build: CNY 2.253552 / 10 (see `budget.json`)

This bundle is a read-only handoff package for the controlled emotion
state-vs-trait study. It contains:

- current source, tests, configs, prompts, frozen rules, rubric, and backend registry;
- the 6-paper material manifest and public source snapshots/search records;
- the frozen study lock, budget, and study state;
- Meta input/response/decision/rule;
- every run attempt, including failed and retried runs (state/messages/final/events/manifest);
- dsh initial review, manual review, blinded proposals, and the separate key.

It excludes credentials, `data/private/`, `review_only/`, `PRIVATE_MAPPING`,
Git internals, caches, and old bundles. No real EEG data are included because
none were read. The proposals are literature-based, not EEG results.

Verify with `python VERIFY_BUNDLE.py`.
