"""Verify every MANIFEST.json entry against its SHA-256."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
errors: list[str] = []
for item in manifest["files"]:
    path = root / item["path"]
    if not path.is_file():
        errors.append(f"missing: {item['path']}")
        continue
    if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        errors.append(f"hash mismatch: {item['path']}")
if errors:
    raise SystemExit("\n".join(errors))
print(f"OK: {len(manifest['files'])} files verified")
